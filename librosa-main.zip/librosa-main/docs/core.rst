.. _core:

.. automodule:: librosa
